window.insertConvertFormShortcode=function(o,e){var n=document.getElementById("jform_convertformid").value;return window.parent.Joomla.editors.instances[o].replaceSelection("{convertforms "+n+"}"),e?window.parent.Joomla.Modal.getCurrent().close():window.parent.jModalClose(),!1};

