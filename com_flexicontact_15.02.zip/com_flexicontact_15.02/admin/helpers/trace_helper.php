<?php
/********************************************************************
Product		: Flexicontact
Date		: 29 November 2023
Copyright	: Les Arbres Design 2010-2023
Contact		: https://www.lesarbresdesign.info
Licence		: GNU General Public License
*********************************************************************/
defined('_JEXEC') or die('Restricted Access');

use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Installer\Installer;
use Joomla\CMS\Uri\Uri;

define("LAFC_TRACE_FILE_NAME", 'trace.txt');
define("LAFC_TRACE_FILE_PATH", JPATH_ROOT.'/components/com_flexicontact/trace.txt');
define("LAFC_TRACE_FILE_URL", Uri::root().'components/'.LAFC_COMPONENT.'/trace.txt');
define("LAFC_MAX_TRACE_SIZE", 1000000);	// about 1Mb
define("LAFC_MAX_TRACE_AGE",   21600);		// maximum trace file age in seconds (6 hours)
define("LAFC_UTF8_HEADER",     "\xEF"."\xBB"."\xBF");	// UTF8 file header

if (class_exists("FC_trace"))
	return;

class FC_trace
{

//-------------------------------------------------------------------------------
// Write an entry to the trace file
// Tracing is ON if the trace file exists
// if $no_time is true, the date time is not added
//
static function trace($data)
{
	if (@!file_exists(LAFC_TRACE_FILE_PATH))
		return;
	if (filesize(LAFC_TRACE_FILE_PATH) > LAFC_MAX_TRACE_SIZE)
		{
		@unlink(LAFC_TRACE_FILE_PATH);
		@file_put_contents(LAFC_TRACE_FILE_PATH, LAFC_UTF8_HEADER.date("d/m/y H:i").' New trace file created'."\n");
		}
	@file_put_contents(LAFC_TRACE_FILE_PATH, $data."\n",FILE_APPEND);
}

//-------------------------------------------------------------------------------
// Start a new trace file
//
static function init_trace()
{
	self::delete_trace_file();
	@file_put_contents(LAFC_TRACE_FILE_PATH, LAFC_UTF8_HEADER.date("d/m/y H:i").' Tracing Initialised'."\n");
	
	$locale = setlocale(LC_ALL,0);
	$locale_string = print_r($locale, true);
	$langObj = Factory::getLanguage();
	$app = Factory::getApplication();
	$mailfrom = $app->get('mailfrom');
	$fromname = $app->get('fromname');
    if (empty($mailfrom))
        $mailfrom = "***** Global Config mailfrom is BLANK *****";
    if (empty($fromname))
        $fromname = "***** Global Config fromname is BLANK *****";

	$xml_array = Installer::parseXMLInstallFile(JPATH_ADMINISTRATOR.'/components/com_flexicontact/flexicontact.xml');
	$component_version = $xml_array['version'];
        
	self::trace("Component version: ".$component_version);
	self::trace("PHP version      : ".phpversion());
	self::trace("PHP Locale       : ".$locale_string);
	self::trace("Server           : ".PHP_OS);
	self::trace("Joomla Version   : ".JVERSION);
	self::trace("Joomla Language  : ".$langObj->get('tag'));
	self::trace("Session Lifetime : ".$app->get('lifetime').' minutes');
	self::trace("Uri::root()     : ".Uri::root());
	self::trace("JPATH_SITE       : ".JPATH_SITE);
	self::trace("Joomla Live_site : ".$app->get('live_site'));
	self::trace("Joomla Caching   : ".$app->get('caching'));
	self::trace("Joomla Mailer    : ".$app->get('mailer'));
	self::trace("Joomla Mail From : ".$mailfrom);
	self::trace("Joomla From Name : ".$fromname);
	self::trace("Joomla Session   : ".$app->get('session_handler'));
	if (PluginHelper::isEnabled('system', 'cache'))
		self::trace("Sys Cache Plugin : Enabled");
	else
		self::trace("Sys Cache Plugin : Not enabled");
}

//-------------------------------------------------------------------------------
// Trace an entry point
// Tracing is ON if the trace file exists
//
static function trace_entry_point($front=false)
{
	if (@!file_exists(LAFC_TRACE_FILE_PATH))
		return;
		
// if the trace file is more than 6 hours old, delete it, which will switch tracing off
//  - we don't want trace to be left on accidentally

	$filetime = @filemtime(LAFC_TRACE_FILE_PATH);
	if (time() > ($filetime + LAFC_MAX_TRACE_AGE))
		{
		self::delete_trace_file();
		return;
		}
	$date_time = date("d/m/y H:i:s").' ';	
	if ($front)
		self::trace("\n".$date_time.'================================ [Front Entry Point] ================================');
	else
		self::trace("\n".$date_time.'================================ [Admin Entry Point] ================================');
	$input = Factory::getApplication()->input;
	$method = $input->server->getString('REQUEST_METHOD','');
	$ip_address = $input->server->getString('REMOTE_ADDR','');
	$request_uri = $input->server->getString('REQUEST_URI','');  // includes all GET data
	$requested_with = $input->server->getString('HTTP_X_REQUESTED_WITH','');
	if ($requested_with == 'XMLHttpRequest')
		$method .= ' by AJAX';
	self::trace("$method from $ip_address @ $request_uri");
	$langObj = Factory::getLanguage();
	$language = $langObj->get('tag');
	self::trace("Site language is $language");
	if ($front)
		{
		if (!empty($input->server->getString('HTTP_USER_AGENT','')))
			self::trace('HTTP_USER_AGENT: '.$input->server->getString('HTTP_USER_AGENT',''));
		if (!empty($input->server->getString('HTTP_REFERER','')))
			self::trace('HTTP_REFERER: '.$input->server->getString('HTTP_REFERER',''));
		if (!empty($input->server->getString('HTTP_CONTENT_TYPE','')))
			self::trace('HTTP_CONTENT_TYPE: '.$input->server->getString('HTTP_CONTENT_TYPE',''));
		$session = Factory::getApplication()->getSession();
		$session_id = $session->getId();
		self::trace("Joomla session ID: $session_id");
		}
	if (!empty($input->get->getArray()))
		self::trace("Get data: ".print_r($input->get->getArray(),true));
	if (!empty($input->post->getArray()))
		self::trace("Post data: ".print_r($input->post->getArray(),true));
	if (!empty($input->files->getArray()))
		self::trace('File data: '.print_r($input->files->getArray(),true));
}

//-------------------------------------------------------------------------------
// Delete the trace file
//
static function delete_trace_file()
{
	if (@file_exists(LAFC_TRACE_FILE_PATH))
		@unlink(LAFC_TRACE_FILE_PATH);
}

//-------------------------------------------------------------------------------
// Return true if tracing is currently active
//
static function tracing()
{
	if (@file_exists(LAFC_TRACE_FILE_PATH))
		return true;
	else
		return false;
}

}