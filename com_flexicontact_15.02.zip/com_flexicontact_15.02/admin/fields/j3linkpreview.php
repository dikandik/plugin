<?php
/********************************************************************
Product		: Multiple Products
Date		: 30 November 2023
Copyright	: Les Arbres Design 2010-2023
Contact		: https://www.lesarbresdesign.info
Licence		: GNU General Public License
*********************************************************************/
defined('_JEXEC') or die('Restricted Access');

JFormHelper::loadFieldClass('text');

class JFormFieldJ3Linkpreview extends JFormFieldText
{
protected $type = 'j3linkpreview';

protected function getInput()
{    
    $button = '<button type="button" class="btn btn-info ladj-preview" data-jroot="'.JURI::root(true).'">'.JText::_('JGLOBAL_PREVIEW').'</button>';    
	$html = parent::getInput();
    return $html.$button;
}

}