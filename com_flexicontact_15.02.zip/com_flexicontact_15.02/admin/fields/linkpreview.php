<?php
/********************************************************************
Product		: Multiple Products
Date		: 29 November 2023
Copyright	: Les Arbres Design 2010-2023
Contact		: https://www.lesarbresdesign.info
Licence		: GNU General Public License
*********************************************************************/
defined('_JEXEC') or die('Restricted Access');

use Joomla\CMS\Language\Text;
use Joomla\CMS\Form\Field\TextField;
use Joomla\CMS\Uri\Uri;

class JFormFieldLinkpreview extends TextField
{
protected $type = 'linkpreview';

protected function getInput()
{    
    $button = '<button type="button" class="btn btn-info ladj-preview" data-jroot="'.Uri::root(true).'">'.Text::_('JGLOBAL_PREVIEW').'</button>';    
	$html = parent::getInput();
    return $html.$button;
}

}