<?php
/********************************************************************
Product		: Flexicontact
Date		: 29 November 2023
Copyright	: Les Arbres Design 2010-2023
Contact		: https://www.lesarbresdesign.info
Licence		: GNU General Public License
*********************************************************************/
defined('_JEXEC') or die('Restricted Access');

use Joomla\CMS\Language\Text;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;

// Check for ACL access

$user = Factory::getApplication()->getIdentity();
if (!$user->authorise('core.manage', 'com_flexicontact'))
    {
	$app = Factory::getApplication();
    $app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
	return;
    }

// Pull in the helper files

require_once JPATH_ADMINISTRATOR.'/components/com_flexicontact/helpers/flexicontact_helper.php';
require_once LAFC_HELPER_PATH.'/trace_helper.php';

// load our css

$document = Factory::getDocument();
if (substr(JVERSION,0,1) == '3')
    $document->addStyleSheet(Uri::root().'administrator/components/com_flexicontact/assets/com_flexicontact_j3.css?'.filemtime(JPATH_ADMINISTRATOR.'/components/com_flexicontact/assets/com_flexicontact_j3.css'));
else
    $document->addStyleSheet(Uri::root().'administrator/components/com_flexicontact/assets/com_flexicontact_j4.css?'.filemtime(JPATH_ADMINISTRATOR.'/components/com_flexicontact/assets/com_flexicontact_j4.css'));

HTMLHelper::_('jquery.framework');           // make sure jQuery loads first ... 
$document->addScript(LAFC_ADMIN_ASSETS_URL.'com_flexicontact.js?v=1400');

// create an instance of the controller and tell it to execute $task

require_once( JPATH_ADMINISTRATOR.'/components/com_flexicontact/controller.php' );
$controller	= new FlexicontactController();
$jinput = Factory::getApplication()->input;
$task = $jinput->get('task', 'config', 'STRING');
$controller->execute($task);
$controller->redirect();