<?php
/********************************************************************
Product		: Flexicontact
Date		: 29 November 2023
Copyright	: Les Arbres Design 2023
Contact		: https://www.lesarbresdesign.info
Licence		: GNU General Public License
*********************************************************************/
defined('_JEXEC') or die('Restricted Access');

use Joomla\CMS\Component\Router\RouterBase;

class FlexicontactRouter extends RouterBase
{

public function build(&$query)
{
	unset($query['view']);
	return array();
}

public function parse(&$segments)
{
	return array();
}

} 