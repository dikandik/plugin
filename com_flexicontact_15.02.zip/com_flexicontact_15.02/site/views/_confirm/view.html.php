<?php
/********************************************************************
Product		: Flexicontact
Date		: 29 November 2023
Copyright	: Les Arbres Design 2009-2023
Contact		: https://www.lesarbresdesign.info
Licence		: GNU General Public License
*********************************************************************/
defined('_JEXEC') or die('Restricted Access');

use Joomla\CMS\MVC\View\HtmlView;

class FlexicontactView_Confirm extends HtmlView
{
function display($tpl = null)
	{
	echo '<div class="fc_conf">'.$this->message."</div>";
	}
}
